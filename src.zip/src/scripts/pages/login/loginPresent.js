import { loginModel } from "./loginModel.js";
import { renderLoginView, showLoginAlert } from "./loginView.js";
import { withViewTransition } from "../../utils/transition.js";

export function renderLogin() {
  const main = document.getElementById("main");
  if (!main) return;
  main.innerHTML = renderLoginView();
  attachLoginEvents();
}

function attachLoginEvents() {
  const form = document.getElementById("login-form");
  if (form) {
    form.addEventListener("submit", onSubmit);
  }
  const toRegisterLink = document.querySelector('a[href="#/register"]');
  if (toRegisterLink) {
    toRegisterLink.addEventListener("click", (e) => {
      e.preventDefault();
      withViewTransition(() => {
        window.location.hash = "#/register";
      }).finished.then(() => {
        document.dispatchEvent(new Event("rerender"));
      });
    });
  }
}

async function onSubmit(e) {
  e.preventDefault();
  const form = e.currentTarget;
  const email = form.email.value.trim();
  const password = form.password.value;
  if (!email || !password) {
    showLoginAlert("Email dan Password harus diisi!");
    return;
  }
  const result = await loginModel.loginUser(email, password);
  if (!result.error) {
    localStorage.setItem("token", result.loginResult.token);
    showLoginAlert("Login berhasil!");
    withViewTransition(() => {
      window.location.hash = "#/home";
    }).finished.then(() => {
      document.dispatchEvent(new Event("rerender"));
    });
  } else {
    showLoginAlert("Login gagal: " + result.message);
  }
}

export function loginPresenter() {
  attachLoginEvents();
}
