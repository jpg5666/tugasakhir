import { registerModel } from "./registerModel.js";
import { renderRegisterView } from "./registerView.js";
import { withViewTransition } from "../../utils/transition.js";

export function renderRegister() {
  const main = document.getElementById("main");
  if (!main) return;
  main.innerHTML = renderRegisterView();
  attachRegisterEvents();
}

function attachRegisterEvents() {
  const form = document.getElementById("register-form");
  if (form) {
    form.addEventListener("submit", onSubmit);
  }
  const toLoginLink = document.querySelector('a[href="#/login"]');
  if (toLoginLink) {
    toLoginLink.addEventListener("click", (e) => {
      e.preventDefault();
      withViewTransition(() => {
        window.location.hash = "#/login";
      }).finished.then(() => {
        document.dispatchEvent(new Event("rerender"));
      });
    });
  }
}

async function onSubmit(e) {
  e.preventDefault();
  const form = e.currentTarget;
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const password = form.password.value;
  if (!name || !email || !password) {
    alert("Semua kolom wajib diisi!");
    return;
  }
  if (password.length < 6) {
    alert("Password minimal 6 karakter!");
    return;
  }
  const result = await registerModel.registerUser(name, email, password);
  if (!result.error) {
    alert("Registrasi berhasil! Silakan login.");
    withViewTransition(() => {
      window.location.hash = "#/login";
    }).finished.then(() => {
      document.dispatchEvent(new Event("rerender"));
    });
  } else {
    alert("Registrasi gagal: " + result.message);
  }
}

export function registerPresenter() {
  attachRegisterEvents();
}
