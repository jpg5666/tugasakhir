export function renderHome() {
  return `
    <section class="home-section">
      <h2>Daftar Cerita</h2>
      <div id="story-list" class="story-list"></div>
      <div class="upload-float-btn">
        <label for="upload-modal-toggle" class="floating-button">+</label>
      </div>
      <input type="checkbox" id="upload-modal-toggle" hidden>
      <div class="upload-modal">
        <div class="upload-box">
          <h3>Tambah Cerita</h3>
          <form id="upload-form">
            <input type="text" id="desc" placeholder="Deskripsi" required><br>
            <video id="camera-preview" autoplay playsinline width="100%" style="max-height:200px;"></video>
            <img id="captured-preview" style="max-height:200px; display: none;" />
            <canvas id="camera-canvas" style="display: none;"></canvas>
            <button type="button" id="capture-btn">Ambil Gambar</button><br>
            <input type="file" id="photo" style="display:none;" />
            <div id="map" style="height: 200px; margin-top: 10px;"></div>
            <input type="hidden" id="lat" name="lat">
            <input type="hidden" id="lon" name="lon">
            <button type="submit">Upload</button>
          </form>
          <label for="upload-modal-toggle" class="close-button">X</label>
        </div>
      </div>
    </section>
  `;
}

export function renderStoryList(stories) {
  const container = document.getElementById("story-list");
  if (!container) return;

  container.innerHTML = stories
    .map(
      (story) => `
        <div class="story-card">
          <img src="${story.photoUrl}" alt="${story.name}" class="story-img" />
          <h3>${story.name}</h3>
          <p>${story.description}</p>
          <small>${new Date(story.createdAt).toLocaleString()}</small>
        </div>
      `
    )
    .join("");
}

export function setupUploadViewEvents({ onCapture, onSubmit, onModalOpen, onModalClose }) {
  const form = document.getElementById("upload-form");
  const captureBtn = document.getElementById("capture-btn");
  const modalToggle = document.getElementById("upload-modal-toggle");

  if (modalToggle) {
    modalToggle.addEventListener("change", () => {
      if (modalToggle.checked) {
        onModalOpen();
      } else {
        onModalClose();
      }
    });
  }

  if (captureBtn) {
    captureBtn.addEventListener("click", onCapture);
  }

  if (form) {
    form.addEventListener("submit", onSubmit);
  }
}

export function getUploadElements() {
  return {
    form: document.getElementById("upload-form"),
    video: document.getElementById("camera-preview"),
    canvas: document.getElementById("camera-canvas"),
    previewImg: document.getElementById("captured-preview"),
    fileInput: document.getElementById("photo"),
    descInput: document.getElementById("desc"),
    modalToggle: document.getElementById("upload-modal-toggle"),
  };
}

export function updateLatLonInputs(lat, lon) {
  const latInput = document.getElementById("lat");
  const lonInput = document.getElementById("lon");
  if (latInput && lonInput) {
    latInput.value = lat;
    lonInput.value = lon;
  }
}

export function getLatLonInputs() {
  const lat = document.getElementById("lat")?.value;
  const lon = document.getElementById("lon")?.value;
  return { lat, lon };
}

export function showAlert(message) {
  alert(message);
}

export function togglePreview(show, src = "") {
  const { previewImg, video } = getUploadElements();
  if (show) {
    previewImg.src = src;
    previewImg.style.display = "block";
    video.style.display = "none";
  } else {
    previewImg.style.display = "none";
    video.style.display = "block";
  }
}

export function initUploadMap({ onLatLngUpdate }) {
  const map = L.map("map").setView([-6.2, 106.8], 13);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);

  const customIcon = L.icon({
    iconUrl: "./images/user.png",
    iconSize: [40, 40],
    iconAnchor: [20, 40],
    popupAnchor: [0, -40],
  });

  const marker = L.marker([-6.2, 106.8], {
    draggable: true,
    icon: customIcon,
  }).addTo(map);

  marker.on("moveend", (e) => {
    const { lat, lng } = e.target.getLatLng();
    onLatLngUpdate(lat, lng);
  });

  map.on("click", (e) => {
    marker.setLatLng(e.latlng);
    onLatLngUpdate(e.latlng.lat, e.latlng.lng);
  });

  return {
    setMarkerPosition(lat, lon) {
      map.setView([lat, lon], 15);
      marker.setLatLng([lat, lon]);
      onLatLngUpdate(lat, lon);
    },
  };
}
