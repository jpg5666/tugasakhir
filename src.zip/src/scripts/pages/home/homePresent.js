import {
  renderHome,
  renderStoryList,
  setupUploadViewEvents,
  getUploadElements,
  initUploadMap,
  updateLatLonInputs,
  showAlert,
  togglePreview,
  getLatLonInputs,
} from "./homeView.js";
import { homeModel } from "./homeModel.js";
import "../../../styles/styles.css";
import { withViewTransition } from "../../utils/transition.js";

let mediaStream = null;
let captured = false;
let mapInstance = null;

export function renderHomePage() {
  const main = document.getElementById("main");
  if (main) {
    withViewTransition(() => {
      main.innerHTML = renderHome();
    });
  }
}

export async function homePresenter() {
  const stories = await homeModel.fetchStoriesWithLocation();
  renderStoryList(stories);

  setupUploadViewEvents({
    onModalOpen: handleModalOpen,
    onModalClose: handleModalClose,
    onCapture: handleCapture,
    onSubmit: handleSubmit,
  });
}

function handleModalOpen() {
  const { video } = getUploadElements();
  captured = false;
  togglePreview(false);

  navigator.mediaDevices
    .getUserMedia({ video: true })
    .then((stream) => {
      mediaStream = stream;
      video.srcObject = mediaStream;
    })
    .catch(() => {
      showAlert("Tidak bisa mengakses kamera");
    });

  if (!mapInstance) {
    mapInstance = initUploadMap({
      onLatLngUpdate: (lat, lon) => updateLatLonInputs(lat, lon),
    });

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        mapInstance.setMarkerPosition(lat, lon);
        updateLatLonInputs(lat, lon);
      },
      () => {
        mapInstance.setMarkerPosition(-6.2, 106.8);
      }
    );
  }
}

function handleModalClose() {
  const { form, fileInput, previewImg, video } = getUploadElements();
  stopCamera(video);
  resetUploadForm(form, fileInput, previewImg, video);
}

function handleCapture() {
  const { video, canvas, fileInput } = getUploadElements();

  if (!mediaStream) return showAlert("Kamera belum aktif");

  const context = canvas.getContext("2d");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  canvas.toBlob(
    (blob) => {
      const file = new File([blob], "captured.jpg", { type: "image/jpeg" });
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      captured = true;
      togglePreview(true, URL.createObjectURL(file));
    },
    "image/jpeg",
    0.9
  );
}

async function handleSubmit(e) {
  e.preventDefault();
  const { descInput, fileInput, form, previewImg, video, modalToggle } = getUploadElements();
  const { lat, lon } = getLatLonInputs();

  const description = descInput.value.trim();
  const photo = fileInput.files[0];

  if (!captured || !photo) {
    showAlert("Silakan ambil gambar terlebih dahulu!");
    return;
  }

  const formData = new FormData();
  formData.append("description", description);
  formData.append("photo", photo);
  formData.append("lat", lat);
  formData.append("lon", lon);

  await uploadAndRefresh(formData, form, fileInput, previewImg, video, modalToggle);
}

async function uploadAndRefresh(formData, form, fileInput, previewImg, video, modalToggle) {
  const result = await homeModel.uploadStory(formData);
  if (!result.error) {
    const updatedStories = await homeModel.fetchStoriesWithLocation();
    renderStoryList(updatedStories);
    stopCamera(video);
    resetUploadForm(form, fileInput, previewImg, video);
    modalToggle.checked = false;
    showAlert("Cerita berhasil diunggah!");
  } else {
    showAlert(result.message || "Gagal mengunggah cerita");
  }
}

function stopCamera(videoElement) {
  if (mediaStream) {
    mediaStream.getTracks().forEach((track) => track.stop());
    videoElement.srcObject = null;
    mediaStream = null;
  }
}

function resetUploadForm(form, fileInput, previewImg, video) {
  form.reset();
  fileInput.value = "";
  previewImg.src = "";
  previewImg.style.display = "none";
  video.style.display = "block";
  captured = false;
}
